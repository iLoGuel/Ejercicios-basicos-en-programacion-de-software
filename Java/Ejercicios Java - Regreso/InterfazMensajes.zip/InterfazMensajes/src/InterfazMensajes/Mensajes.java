package InterfazMensajes;

import javax.swing.JOptionPane;

public class Mensajes {

    public void n1Mensajes1() {
        JOptionPane.showMessageDialog(null, "Este es un mensaje normal");
    }

    public void n2Mensajes2() {
        String nl = System.getProperty("Line.separator");
        JOptionPane.showMessageDialog(null, "Este es un mensaje normal" + nl + "Mensaje de varias lineas");
    }

    public void n3Mensajes3() {
        Object enunciado = "Mensaje_3, mensaje informativo";
        JOptionPane.showMessageDialog(null, enunciado, "Mensaje informativo", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void n4Mensajes4() {
        Object enunciado = "Mensaje_4, ¿Estas seguro que desea usted continuar?";
        JOptionPane.showMessageDialog(null, enunciado, "Mensaje interrogativo", JOptionPane.QUESTION_MESSAGE);
    }
    
    public void n5Mensajes5() {
        Object enunciado = "Mensaje_5, El dato o accion realizada es realizada";
        JOptionPane.showMessageDialog(null, enunciado, "Mensaje de error", JOptionPane.ERROR_MESSAGE);
    }
    public void n6Mensajes6() {
        Object enunciado = "Mensaje_6, Al realizar la accion puede perder los datos";
        JOptionPane.showMessageDialog(null, enunciado, "Mensaje de advertencia", JOptionPane.WARNING_MESSAGE);
    }
    
}
